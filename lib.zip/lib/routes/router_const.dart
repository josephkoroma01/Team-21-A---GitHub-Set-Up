class RouteNames {
  static const String welcomescreen = '/';
  static const String login = '/login';
  static const String signup = '/signup';
  
}
