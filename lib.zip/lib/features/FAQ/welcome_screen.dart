import 'package:flutter/material.dart';
import 'package:lifebloodworld/features/FAQ/components/body.dart';

class FAQPageScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FAQBody(),
    );
  }
}
