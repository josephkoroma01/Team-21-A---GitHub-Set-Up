import 'package:flutter/material.dart';
import 'package:lifebloodworld/features/More/components/body.dart';


class MeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: memorebody(),
    );
  }
}
